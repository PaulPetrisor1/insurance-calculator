import React from 'react';
import "../CSS/Insert.css";

 const Insert =(props) =>

 <div className ="insert">
 {props.insert}
 </div>

 export default Insert;
